
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.0.1'
version = '1.0.1'
full_version = '1.0.1'
git_revision = '83eb32d32f9a4d8fcb03dc75478f39c8f1cb7686'
release = True

if not release:
    version = full_version
